<?php

return [
    'Permissions'=>"الصلاحيات",
    'create permissions'=>'انشاء صلاحيه',

];
