<?php

return [
    'Roles'=>"الادوار",
    'showroles'=>'عؤض الأدوار',

];
