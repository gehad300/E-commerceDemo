<?php

return [
    'createStore'=>'انشاء متجر',
    'stores'=>'كل المتاجر',
    'store'=>'متجر',
];
