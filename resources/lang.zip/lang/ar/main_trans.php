<?php

return [
    'Dashboard' => 'لوحة التحكم',
    'Arabic'   => 'عربي',
    'English' => 'إنجليزي'
];
