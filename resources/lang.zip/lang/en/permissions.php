<?php

return [
    'Permissions'=>"Permissions",
    'create permissions'=>'create permissions',

];
