<?php

return [
    'createStore'=>'create store',
    'stores'=>'stores',
    'store'=>'store',

];
