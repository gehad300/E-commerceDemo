<?php

return [

    'Dashboard' =>  'Dashboard',
    'Arabic'   => 'Arabic',
    'English' => 'English'
];
